window.addEventListener('load', function () {

	window.vue = new Vue({

		el: '#app',
		data: {
			message: 'hey dude!',
			isLoading: true,
			willShow: false,
			singlepost : [],

			posts: [],

		},

		// ready:function() {
		//  	this.created();
		//  },

		created(){
		   axios.get('https://jsonplaceholder.typicode.com/posts')
		        .then(response => {
		          // console.log(response); // show if success
		          this.isLoading = false;
		          this.posts = response.data; //we are putting data into our posts array
		           
		        })
		        .catch(function (error) {
		          console.log(error); // run if we have error
		        });    
		 },

		 


		 methods: {
		 	showPost(id){
		 		axios.get('https://jsonplaceholder.typicode.com/posts/' + id)
		        .then(response => {
		          // console.log(response); // show if success
		          this.willShow = true;
		          this.singlepost = response.data; //we are putting data into our posts array
		           
		        })
		        .catch(function (error) {
		          console.log(error); // run if we have error
		        });  
		 	},

		 	addPost(){

		 		axios.post('https://jsonplaceholder.typicode.com/posts', {
					content: this.content		 			
		 		})
		 		.then(function(response) {
			 		console.log('saved');
			 	})
			 	.catch(function(error) {
			 		console.log(error);
			 	})
		 	}
		 	
		 } 
	});

});