import readme from './README.md';

export default {
    readme,
    meta: {
        title: 'Spacing classes'
    }
};
