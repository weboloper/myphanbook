<template> </template>

<script>
    export default {
        fetch({ redirect }) {
            redirect('/docs')
        }
    };
</script>
