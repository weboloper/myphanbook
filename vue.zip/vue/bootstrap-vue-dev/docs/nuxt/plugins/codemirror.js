import Vue from 'vue';
import CodeMirror from '../components/codemirror.vue';

Vue.component('codemirror', CodeMirror);
