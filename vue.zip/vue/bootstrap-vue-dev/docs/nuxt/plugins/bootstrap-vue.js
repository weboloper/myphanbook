import Vue from 'vue';
import BootstrapVue from '../../../lib';

Vue.use(BootstrapVue);
