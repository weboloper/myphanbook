<template>
    <footer class="bd-footer text-muted">
        <div class="container">

            <ul class="bd-footer-links">
                <li>
                    <router-link to="/">Home</router-link>
                </li>
                <li>
                    <router-link to="/docs/">Documentation</router-link>
                </li>
                <li>
                    <a href="https://github.com/bootstrap-vue/bootstrap-vue" target="_blank">Fork on GitHub</a>
                </li>
            </ul>

            <p>
                Designed and built with all the love in the world.
                Maintained by the <a href="https://github.com/orgs/bootstrap-vue/people">core team</a>
                With the help of
                <a href="https://github.com/bootstrap-vue/bootstrap-vue/graphs/contributors">our contributors</a>.
                docs generated with <a href="https://nuxtjs.org/">NUXT.js</a>
            </p>

        </div>
    </footer>
</template>

<script>
    import site from '../..';

    export default{
        data() {
            return {
                site
            };
        }
    };
</script>
