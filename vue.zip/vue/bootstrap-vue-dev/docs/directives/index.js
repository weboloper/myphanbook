/* eslint-disable quote-props */

export default {
    'tooltip': require('./tooltip').default,
    'popover': require('./popover').default,
    'scrollspy': require('./scrollspy').default
};
