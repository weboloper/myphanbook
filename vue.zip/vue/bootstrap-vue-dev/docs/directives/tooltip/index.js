import readme from './README.md';

export default {
    readme,
    meta: {
        title: 'Tooltip',
        new: true
    }
};
