import meta from './meta.json';
import readme from './README.md';

export default {meta, readme};
