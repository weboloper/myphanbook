<template>
    <span>
        Test Component
    </span>
</template>

<style>
    .foo {
        color: blue
    }
</style>

<script>
    export default {};
</script>
