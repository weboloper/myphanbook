import {loadFixture, testVM} from '../helpers';

describe('form-radio', async() => {
    beforeEach(loadFixture('form-radio'));
    testVM();
});