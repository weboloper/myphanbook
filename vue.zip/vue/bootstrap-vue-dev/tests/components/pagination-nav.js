import {loadFixture, testVM} from '../helpers';

describe('pagination-nav', async() => {
    beforeEach(loadFixture('pagination-nav'));
    testVM();
});
