import {loadFixture, testVM} from '../helpers';

describe('form-checkbox', async() => {
    beforeEach(loadFixture('form-checkbox'));
    testVM();
});