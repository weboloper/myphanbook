import {loadFixture, testVM} from '../helpers';

describe('form-input', async() => {
    beforeEach(loadFixture('form-input'));
    testVM();
});