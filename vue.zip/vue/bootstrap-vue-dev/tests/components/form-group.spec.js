import {loadFixture, testVM} from '../helpers';

describe('form-group', async() => {
    beforeEach(loadFixture('form-group'));
    testVM();
});
