import {loadFixture, testVM} from '../helpers';

describe('form-file', async() => {
    beforeEach(loadFixture('form-file'));
    testVM();
});