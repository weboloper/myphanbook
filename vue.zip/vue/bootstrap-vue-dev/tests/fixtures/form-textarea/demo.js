window.app = new Vue({
    el: '#app',
    data: {
        text: '',
        value: 'This is some text that could be long\nor not really long'
    }
});
