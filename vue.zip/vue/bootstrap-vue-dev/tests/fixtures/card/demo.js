window.app = new Vue({
    el: "#app",
    data: {
        headerText: "Card header text",
        img0: "http://placeskull.com/200/200/ABABAB/-1/0",
        img1: "http://placeskull.com/200/200/E8117F/-1/0",
    }
})
